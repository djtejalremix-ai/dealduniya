# DealDuniya — GitHub Pages

This is a static storefront for GitHub Pages.

## Publish

1. Sign in to GitHub as `djtejalremixai`.
2. Create a **Public** repository named `dealduniya`.
3. Upload `index.html` from this folder to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then Save.
7. Wait for the Pages deployment to finish.

Expected URL:
https://djtejalremixai.github.io/dealduniya/

## Update product cards

Open `index.html` and find `const products = [`.
Edit or copy a product object. Each product supports:
- `category`: Fashion, Home, Beauty, Accessories, Kids
- `name`, `description`, `price`, `tag`
- `meeshoUrl`: the actual Meesho listing URL
- `image`: a publicly accessible image URL (leave blank to show the emoji)

Commit the changed `index.html` to the `main` branch. GitHub Pages will redeploy automatically.

## Important limitation

GitHub Pages is static hosting. This version has no secure admin login, shared database, or browser-based product editor. Product changes are made by editing `index.html` and committing the file to GitHub. A secure admin panel that updates products for all visitors requires a separate backend/database and authentication service.

The product cards currently contain sample placeholders. Verify product names, images, prices, availability and delivery details against each live Meesho listing before publishing.
